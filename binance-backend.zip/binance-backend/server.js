/**
 * ─────────────────────────────────────────────────────────────
 *  BINANCE AI BOT — BACKEND SERVER
 *  Deploy on Railway.app or Render.com (free tier)
 *  Your API keys stay on YOUR server — never in the browser
 * ─────────────────────────────────────────────────────────────
 */

require('dotenv').config();
const express    = require('express');
const cors       = require('cors');
const crypto     = require('crypto');
const https      = require('https');

const app  = express();
const PORT = process.env.PORT || 3000;

// ── MIDDLEWARE ──────────────────────────────────────────────
app.use(cors({ origin: '*' }));          // Allow your mobile app
app.use(express.json());

// ── BINANCE CONFIG ──────────────────────────────────────────
const BINANCE_BASE   = 'https://api.binance.com';
const FUTURES_BASE   = 'https://fapi.binance.com';

// API keys come from environment variables (set in Railway/Render dashboard)
// NEVER hardcode keys here
const API_KEY    = process.env.BINANCE_API_KEY    || '';
const API_SECRET = process.env.BINANCE_API_SECRET || '';

// ── HELPERS ─────────────────────────────────────────────────
function sign(queryString) {
  return crypto
    .createHmac('sha256', API_SECRET)
    .update(queryString)
    .digest('hex');
}

function binanceRequest(baseUrl, path, method = 'GET', params = {}, signed = false) {
  return new Promise((resolve, reject) => {
    let queryString = Object.entries(params)
      .map(([k, v]) => `${k}=${encodeURIComponent(v)}`)
      .join('&');

    if (signed) {
      const timestamp = Date.now();
      queryString += (queryString ? '&' : '') + `timestamp=${timestamp}`;
      const signature = sign(queryString);
      queryString += `&signature=${signature}`;
    }

    const fullPath = queryString ? `${path}?${queryString}` : path;
    const url = new URL(baseUrl + fullPath);

    const options = {
      hostname: url.hostname,
      path:     url.pathname + url.search,
      method,
      headers: {
        'X-MBX-APIKEY': API_KEY,
        'Content-Type': 'application/json',
      },
    };

    const req = https.request(options, (res) => {
      let data = '';
      res.on('data', chunk => (data += chunk));
      res.on('end', () => {
        try { resolve(JSON.parse(data)); }
        catch (e) { reject(new Error('JSON parse error: ' + data)); }
      });
    });

    req.on('error', reject);
    req.end();
  });
}

// ── HEALTH CHECK ────────────────────────────────────────────
app.get('/', (req, res) => {
  res.json({
    status: 'online',
    server: 'Binance AI Bot Backend',
    version: '1.0.0',
    time: new Date().toISOString(),
    keysLoaded: !!(API_KEY && API_SECRET),
  });
});

// ── TEST CONNECTION ──────────────────────────────────────────
app.get('/api/test', async (req, res) => {
  try {
    if (!API_KEY || !API_SECRET) {
      return res.status(400).json({ error: 'API keys not configured in environment variables' });
    }
    const result = await binanceRequest(BINANCE_BASE, '/api/v3/account', 'GET', {}, true);
    if (result.code) {
      return res.status(400).json({ error: result.msg, code: result.code });
    }
    res.json({ connected: true, accountType: result.accountType, canTrade: result.canTrade });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// ── GET BALANCE ──────────────────────────────────────────────
app.get('/api/balance', async (req, res) => {
  try {
    const account = await binanceRequest(BINANCE_BASE, '/api/v3/account', 'GET', {}, true);
    if (account.code) return res.status(400).json({ error: account.msg });

    const balances = account.balances
      .filter(b => parseFloat(b.free) > 0 || parseFloat(b.locked) > 0)
      .map(b => ({
        asset:  b.asset,
        free:   parseFloat(b.free),
        locked: parseFloat(b.locked),
        total:  parseFloat(b.free) + parseFloat(b.locked),
      }));

    // Get USDT value
    const usdt = balances.find(b => b.asset === 'USDT');
    const totalUSDT = usdt ? usdt.total : 0;

    res.json({
      connected:  true,
      balances,
      totalUSDT:  totalUSDT.toFixed(2),
      canTrade:   account.canTrade,
      updateTime: account.updateTime,
    });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// ── GET LIVE PRICES (public — no auth needed) ────────────────
app.get('/api/prices', async (req, res) => {
  try {
    const symbols = (req.query.symbols || 'BTCUSDT,ETHUSDT,SOLUSDT,BNBUSDT,LINKUSDT,ARBUSDT').split(',');
    const prices  = await Promise.all(
      symbols.map(s =>
        binanceRequest(BINANCE_BASE, '/api/v3/ticker/24hr', 'GET', { symbol: s })
      )
    );
    const result = prices.map(p => ({
      symbol:    p.symbol,
      price:     parseFloat(p.lastPrice),
      change24h: parseFloat(p.priceChangePercent),
      high24h:   parseFloat(p.highPrice),
      low24h:    parseFloat(p.lowPrice),
      volume:    parseFloat(p.quoteVolume),
    }));
    res.json({ prices: result, time: Date.now() });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// ── GET ORDER BOOK ────────────────────────────────────────────
app.get('/api/orderbook/:symbol', async (req, res) => {
  try {
    const data = await binanceRequest(BINANCE_BASE, '/api/v3/depth', 'GET', {
      symbol: req.params.symbol.toUpperCase(),
      limit:  10,
    });
    res.json(data);
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// ── GET OPEN ORDERS ────────────────────────────────────────────
app.get('/api/orders/open', async (req, res) => {
  try {
    const symbol = req.query.symbol;
    const params = symbol ? { symbol } : {};
    const orders = await binanceRequest(BINANCE_BASE, '/api/v3/openOrders', 'GET', params, true);
    if (orders.code) return res.status(400).json({ error: orders.msg });
    res.json({ orders, count: orders.length });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// ── GET ORDER HISTORY ──────────────────────────────────────────
app.get('/api/orders/history', async (req, res) => {
  try {
    const symbol = req.query.symbol || 'BTCUSDT';
    const orders = await binanceRequest(BINANCE_BASE, '/api/v3/allOrders', 'GET', { symbol, limit: 20 }, true);
    if (orders.code) return res.status(400).json({ error: orders.msg });
    res.json({
      orders: orders.map(o => ({
        orderId:     o.orderId,
        symbol:      o.symbol,
        side:        o.side,
        type:        o.type,
        price:       parseFloat(o.price),
        qty:         parseFloat(o.origQty),
        status:      o.status,
        time:        new Date(o.time).toLocaleTimeString(),
      })),
    });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// ── PLACE SPOT ORDER ───────────────────────────────────────────
app.post('/api/order/spot', async (req, res) => {
  try {
    const { symbol, side, type, quantity, price, stopPrice } = req.body;

    if (!symbol || !side || !type || !quantity) {
      return res.status(400).json({ error: 'Missing required fields: symbol, side, type, quantity' });
    }

    const params = {
      symbol:   symbol.toUpperCase(),
      side:     side.toUpperCase(),       // BUY or SELL
      type:     type.toUpperCase(),       // MARKET, LIMIT, STOP_LOSS_LIMIT
      quantity: parseFloat(quantity).toFixed(6),
    };

    if (type.toUpperCase() === 'LIMIT') {
      params.timeInForce = 'GTC';
      params.price = parseFloat(price).toFixed(2);
    }

    if (stopPrice) {
      params.stopPrice = parseFloat(stopPrice).toFixed(2);
    }

    const order = await binanceRequest(BINANCE_BASE, '/api/v3/order', 'POST', params, true);
    if (order.code) return res.status(400).json({ error: order.msg, code: order.code });

    res.json({
      success:  true,
      orderId:  order.orderId,
      symbol:   order.symbol,
      side:     order.side,
      status:   order.status,
      price:    order.price,
      quantity: order.origQty,
    });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// ── CANCEL ORDER ───────────────────────────────────────────────
app.delete('/api/order/:symbol/:orderId', async (req, res) => {
  try {
    const result = await binanceRequest(BINANCE_BASE, '/api/v3/order', 'DELETE', {
      symbol:  req.params.symbol.toUpperCase(),
      orderId: req.params.orderId,
    }, true);
    if (result.code) return res.status(400).json({ error: result.msg });
    res.json({ success: true, orderId: result.orderId, status: result.status });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// ── FUTURES: GET POSITIONS ─────────────────────────────────────
app.get('/api/futures/positions', async (req, res) => {
  try {
    const account = await binanceRequest(FUTURES_BASE, '/fapi/v2/account', 'GET', {}, true);
    if (account.code) return res.status(400).json({ error: account.msg });

    const positions = account.positions
      .filter(p => parseFloat(p.positionAmt) !== 0)
      .map(p => ({
        symbol:        p.symbol,
        side:          parseFloat(p.positionAmt) > 0 ? 'LONG' : 'SHORT',
        size:          Math.abs(parseFloat(p.positionAmt)),
        entryPrice:    parseFloat(p.entryPrice),
        markPrice:     parseFloat(p.markPrice),
        unrealizedPnl: parseFloat(p.unrealizedProfit),
        leverage:      parseInt(p.leverage),
        margin:        parseFloat(p.initialMargin),
      }));

    res.json({
      positions,
      totalWalletBalance:    parseFloat(account.totalWalletBalance),
      totalUnrealizedProfit: parseFloat(account.totalUnrealizedProfit),
    });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// ── FUTURES: PLACE ORDER ───────────────────────────────────────
app.post('/api/futures/order', async (req, res) => {
  try {
    const { symbol, side, type, quantity, price, leverage } = req.body;

    if (!symbol || !side || !type || !quantity) {
      return res.status(400).json({ error: 'Missing required fields' });
    }

    // Set leverage first
    if (leverage && parseInt(leverage) > 1) {
      await binanceRequest(FUTURES_BASE, '/fapi/v1/leverage', 'POST', {
        symbol:   symbol.toUpperCase(),
        leverage: parseInt(leverage),
      }, true);
    }

    const params = {
      symbol:   symbol.toUpperCase(),
      side:     side.toUpperCase(),
      type:     type.toUpperCase(),
      quantity: parseFloat(quantity).toFixed(3),
    };

    if (type.toUpperCase() === 'LIMIT') {
      params.timeInForce = 'GTC';
      params.price = parseFloat(price).toFixed(2);
    }

    const order = await binanceRequest(FUTURES_BASE, '/fapi/v1/order', 'POST', params, true);
    if (order.code) return res.status(400).json({ error: order.msg, code: order.code });

    res.json({
      success:  true,
      orderId:  order.orderId,
      symbol:   order.symbol,
      side:     order.side,
      status:   order.status,
      avgPrice: order.avgPrice,
      quantity: order.origQty,
    });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// ── FUTURES: OPEN INTEREST (public) ───────────────────────────
app.get('/api/futures/oi/:symbol', async (req, res) => {
  try {
    const data = await binanceRequest(FUTURES_BASE, '/fapi/v1/openInterest', 'GET', {
      symbol: req.params.symbol.toUpperCase(),
    });
    res.json({
      symbol:       data.symbol,
      openInterest: parseFloat(data.openInterest),
      time:         data.time,
    });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// ── KLINES / CANDLES (for chart data) ─────────────────────────
app.get('/api/klines/:symbol', async (req, res) => {
  try {
    const data = await binanceRequest(BINANCE_BASE, '/api/v3/klines', 'GET', {
      symbol:   req.params.symbol.toUpperCase(),
      interval: req.query.interval || '1h',
      limit:    req.query.limit    || 50,
    });
    const candles = data.map(c => ({
      time:   c[0],
      open:   parseFloat(c[1]),
      high:   parseFloat(c[2]),
      low:    parseFloat(c[3]),
      close:  parseFloat(c[4]),
      volume: parseFloat(c[5]),
    }));
    res.json({ symbol: req.params.symbol, candles });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// ── RSI CALCULATOR ─────────────────────────────────────────────
app.get('/api/rsi/:symbol', async (req, res) => {
  try {
    const data = await binanceRequest(BINANCE_BASE, '/api/v3/klines', 'GET', {
      symbol:   req.params.symbol.toUpperCase(),
      interval: req.query.interval || '1h',
      limit:    15,
    });
    const closes = data.map(c => parseFloat(c[4]));
    let gains = 0, losses = 0;
    for (let i = 1; i < closes.length; i++) {
      const diff = closes[i] - closes[i - 1];
      if (diff > 0) gains += diff;
      else losses += Math.abs(diff);
    }
    const avgGain = gains / 14;
    const avgLoss = losses / 14;
    const rs  = avgLoss === 0 ? 100 : avgGain / avgLoss;
    const rsi = 100 - (100 / (1 + rs));
    res.json({
      symbol:   req.params.symbol,
      rsi:      rsi.toFixed(2),
      signal:   rsi < 30 ? 'OVERSOLD — potential BUY' : rsi > 70 ? 'OVERBOUGHT — potential SELL' : 'NEUTRAL',
      interval: req.query.interval || '1h',
    });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// ── START SERVER ───────────────────────────────────────────────
app.listen(PORT, () => {
  console.log(`
╔══════════════════════════════════════════╗
║   BINANCE AI BOT — Backend Server        ║
║   Running on port ${PORT}                   ║
║   Keys loaded: ${!!(API_KEY && API_SECRET) ? 'YES ✓' : 'NO — set .env'}        ║
╚══════════════════════════════════════════╝
  `);
});
