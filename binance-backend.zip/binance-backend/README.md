# ⬡ Binance AI Bot — Backend Setup Guide

## What This Does
This backend server sits between your phone app and Binance.
Your API keys stay on YOUR server — never exposed in the browser.

```
📱 Your Phone App  →  🖥 Your Backend  →  🟡 Binance API
```

---

## 🚀 Deploy on Railway.app (FREE — Easiest)

### Step 1 — Create GitHub Repository
1. Go to **github.com** → Sign up (free)
2. Click **"New repository"**
3. Name it: `binance-bot-backend`
4. Set to **Private** (important for security)
5. Click **Create repository**

### Step 2 — Upload Your Files
Upload these 4 files to GitHub:
- `server.js`
- `package.json`
- `.gitignore`
- `.env.example`

> ⚠️ DO NOT upload `.env` — your keys stay local only

### Step 3 — Deploy on Railway
1. Go to **railway.app** → Sign up with GitHub (free)
2. Click **"New Project"**
3. Click **"Deploy from GitHub repo"**
4. Select your `binance-bot-backend` repo
5. Railway auto-detects Node.js and deploys it ✓

### Step 4 — Add Your API Keys in Railway
1. In Railway dashboard → click your project
2. Click **"Variables"** tab
3. Add these two variables:
   ```
   BINANCE_API_KEY     = your_actual_api_key
   BINANCE_API_SECRET  = your_actual_secret_key
   ```
4. Railway automatically restarts with your keys ✓

### Step 5 — Get Your Server URL
1. In Railway → click **"Settings"** tab
2. Under "Domains" → click **"Generate Domain"**
3. Copy your URL — looks like:
   ```
   https://binance-bot-backend-production.up.railway.app
   ```

### Step 6 — Connect to Your Phone App
1. Open your **Binance AI App** on Android
2. Tap **🔗 CONNECT** tab
3. Paste your Binance API Key
4. Paste your Binance Secret Key
5. Paste your Railway URL in the **Backend URL** field
6. Tap **CONNECT TO BINANCE**
7. ✅ You're live!

---

## 🚀 Alternative: Deploy on Render.com (FREE)

1. Go to **render.com** → Sign up (free)
2. Click **"New Web Service"**
3. Connect your GitHub repo
4. Settings:
   - **Build Command:** `npm install`
   - **Start Command:** `node server.js`
   - **Environment:** Node
5. Add environment variables (same as Railway above)
6. Click **Deploy** → Copy your URL

---

## 🔗 API Endpoints Your App Uses

| Endpoint | What it does |
|----------|-------------|
| `GET /` | Health check — test server is online |
| `GET /api/test` | Test Binance API connection |
| `GET /api/balance` | Your live Binance wallet balance |
| `GET /api/prices` | Live prices for any symbols |
| `GET /api/orders/open` | Your open orders |
| `GET /api/orders/history` | Your order history |
| `POST /api/order/spot` | Place a spot buy/sell order |
| `DELETE /api/order/:symbol/:id` | Cancel an order |
| `GET /api/futures/positions` | Your futures positions |
| `POST /api/futures/order` | Place a futures long/short |
| `GET /api/futures/oi/:symbol` | Open interest for any pair |
| `GET /api/klines/:symbol` | Candle chart data |
| `GET /api/rsi/:symbol` | Live RSI indicator |

---

## ⚠️ Security Checklist

- ✅ Repository is set to PRIVATE on GitHub
- ✅ `.env` file is in `.gitignore` (never uploaded)
- ✅ API keys are in Railway/Render environment variables only
- ✅ Binance API key has NO withdrawal permission
- ✅ Binance API key has IP restriction set (optional but recommended)
- ✅ Never share your Railway/Render URL publicly

---

## 🧪 Test Your Server

Once deployed, visit your URL in a browser:
```
https://YOUR-URL.railway.app/
```

You should see:
```json
{
  "status": "online",
  "server": "Binance AI Bot Backend",
  "keysLoaded": true
}
```

Then test your Binance connection:
```
https://YOUR-URL.railway.app/api/test
```

Should return:
```json
{
  "connected": true,
  "accountType": "SPOT",
  "canTrade": true
}
```

---

## 💰 Cost

| Platform | Free Tier | Paid |
|----------|-----------|------|
| Railway | $5 credit/month (enough for this) | $5/month after |
| Render | 750 hours/month free | $7/month after |
| GitHub | Always free | — |

**Total cost: $0 to start** ✓
